from funcoes import *


print("=-"*30)
print(estaContido("flavio","carol"))
print(estaContido("ar-condicionado","ar"))

print("=-"*30)
print(criaPalavra("abacate","talher","arvore"))
print(criaPalavra("ovo","laranja","arroz"))

print("=-"*30)
listaNumeros=[10,5,7,8,24,35,124,88,100,75]
print(imprimePares(listaNumeros))